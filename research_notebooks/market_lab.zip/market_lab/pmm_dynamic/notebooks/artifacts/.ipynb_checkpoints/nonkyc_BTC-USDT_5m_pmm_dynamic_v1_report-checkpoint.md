# PMM Dynamic Optimization Report: nonkyc_BTC-USDT_5m_pmm_dynamic_v1

Generated: 2026-03-06 22:14:19 UTC

## Dataset Summary

- **connector**: nonkyc
- **trading_pair**: BTC-USDT
- **interval**: 5m
- **n_candles**: 53269
- **dataset_hash**: d63c060b17d2ca8e95be9e6475c6fa67ccde16009d43d7aa56aa52ed34e12834

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 2.793288525665248 |
| buy_n_levels | 5 |
| buy_side_weight | 0.32517677437978004 |
| buy_spread_base | 4.457854559773187 |
| buy_spread_ratio | 2.9381101795499465 |
| cooldown_time | 473.62724379238125 |
| executor_refresh_time | 710.1144288687675 |
| macd_fast | 42 |
| macd_signal | 18 |
| macd_slow | 60 |
| natr_length | 11 |
| sell_n_levels | 4 |
| sell_spread_base | 4.5946128310579 |
| sell_spread_ratio | 1.6872935012499535 |
| stop_loss | 0.08112877254122255 |
| take_profit | 0.007840252139384354 |
| time_limit | 78064 |
| total_amount_quote | 127.76036187462486 |
| trailing_stop_activation | 0.013643649775800775 |
| trailing_stop_delta | 0.018589029068133707 |

## Best Metrics

- **PnL %**: -253.0240
- **Net PnL (quote)**: -253.0240
- **Sharpe Ratio**: 1.7100
- **Max Drawdown %**: 250.8026
- **Profit Factor**: 0.6332167892791907
- **Trade Count**: 5834
- **Total Fees (quote)**: 260.9418
- **Maker Fees**: 97.0412
- **Taker Fees**: 163.9006
- **Fee Drag %**: 260.9418

## Objective Decomposition

- **Raw Score**: -518.4690
- **PnL Component**: -253.0240
- **Sharpe Component**: 0.8550
- **Drawdown Component**: -75.2408
- **Fee Drag Component**: -52.1884
- **Inventory Component**: -138.8708
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **-41.7319**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective |
|------|-------|--------|----------|--------|-----------|
| 0 | -21.61 | -13.16 | 22.96 | 434 | -41.9461 |
| 1 | -28.92 | -10.07 | 29.27 | 446 | -54.1247 |
| 2 | -18.82 | -6.34 | 26.60 | 442 | -41.6161 |
| 3 | -20.80 | -10.57 | 22.23 | 443 | -40.2543 |
| 4 | -14.19 | -6.76 | 18.68 | 452 | -34.2531 |
| 5 | -18.07 | -14.07 | 19.58 | 456 | -37.3794 |
| 6 | -23.07 | -13.37 | 23.48 | 419 | -43.6024 |
| 7 | -12.22 | -5.34 | 16.74 | 433 | -28.5024 |
| 8 | -11.76 | -3.97 | 20.23 | 445 | -31.2467 |
| 9 | -19.16 | -7.87 | 25.90 | 447 | -40.0981 |

## Stress Test Results

Worst Scenario: **fees_2x** (score: -787.6110)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | -383.49 | -1.38 | 379.88 | -606.1046 |
| fees_2x | -513.97 | 0.23 | 509.43 | -787.6110 |
| latency_plus1 | -260.32 | 1.87 | 258.48 | -436.9619 |
| latency_plus2 | -265.81 | 0.29 | 263.75 | -549.1056 |
| latency_plus3 | -259.09 | -1.67 | 257.95 | -502.4949 |
| low_liquidity | -253.15 | -0.01 | 250.93 | -481.1929 |
| very_low_liquidity | -253.16 | 1.04 | 250.94 | -459.4000 |
| high_slippage | -286.44 | 1.41 | 283.74 | -483.5792 |
| extreme_slippage | -353.28 | 1.51 | 349.60 | -658.3942 |
| combined_adverse | -423.05 | 1.30 | 419.84 | -667.3178 |

## Stop-Ship Checks

- dataset_audit: PASS
- feature_parity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: **FAIL**
- yaml_validates: PASS
- determinism: PASS

> **WARNING**: One or more stop-ship checks FAILED.
