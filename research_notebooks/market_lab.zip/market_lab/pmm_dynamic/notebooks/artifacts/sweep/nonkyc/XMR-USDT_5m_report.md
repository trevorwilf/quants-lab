# PMM Dynamic Optimization Report: nonkyc_XMR-USDT_5m_sweep_v1

Generated: 2026-03-07 10:39:37 UTC

## Dataset Summary

- **connector**: nonkyc
- **trading_pair**: XMR-USDT
- **interval**: 5m
- **n_candles**: 53171
- **dataset_hash**: 72cddd298d5518f45c96e471427285075ad68753e8803d535335aba6c4c310b8
- **n_trials_phase1**: 3000
- **n_candidates_stressed**: 50

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 2.314930737753728 |
| buy_n_levels | 5 |
| buy_side_weight | 0.21546890905245714 |
| buy_spread_base | 2.970538547835486 |
| buy_spread_ratio | 2.4212745981736763 |
| cooldown_time | 748.1354195847557 |
| executor_refresh_time | 1452.3250779003265 |
| macd_fast | 10 |
| macd_signal | 7 |
| macd_slow | 56 |
| natr_length | 50 |
| sell_n_levels | 9 |
| sell_spread_base | 1.673250993544517 |
| sell_spread_ratio | 1.2509953585427906 |
| stop_loss | 0.16493480838606817 |
| take_profit | 0.1371620989966573 |
| time_limit | 141021 |
| total_amount_quote | 80.51712017316045 |
| trailing_stop_activation | 0.035149507647847446 |
| trailing_stop_delta | 0.00195024125005289 |

## Best Metrics

- **PnL %**: 354.8191
- **Net PnL (quote)**: 285.6901
- **Sharpe Ratio**: 1.5544
- **Max Drawdown %**: 52.9065
- **Profit Factor**: 1.2501406520852623
- **Trade Count**: 4099
- **Total Fees (quote)**: 156.3693
- **Maker Fees**: 52.6173
- **Taker Fees**: 103.7519
- **Fee Drag %**: 194.2062

## Objective Decomposition

- **Raw Score**: 297.5647
- **PnL Component**: 354.8191
- **Sharpe Component**: 0.7772
- **Drawdown Component**: -15.8719
- **Fee Drag Component**: -38.8412
- **Inventory Component**: -3.1420
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **4.7744**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective |
|------|-------|--------|----------|--------|-----------|
| 0 | 67.35 | 5.58 | 1.07 | 114 | 68.6474 |
| 1 | 18.61 | 12.48 | 2.64 | 149 | 18.4428 |
| 2 | 9.37 | 9.17 | 5.35 | 109 | 9.0538 |
| 3 | 7.85 | 13.21 | 0.79 | 101 | 9.1481 |
| 4 | 0.58 | 1.71 | 1.37 | 93 | 0.3361 |
| 5 | 1.09 | 4.17 | 1.01 | 109 | 2.0406 |
| 6 | -5.54 | -1.81 | 19.48 | 160 | -15.1159 |
| 7 | 11.17 | 10.17 | 2.91 | 143 | 11.2573 |
| 8 | 3.65 | 6.42 | 2.87 | 102 | 4.4403 |
| 9 | 3.77 | 10.92 | 1.72 | 93 | 5.1033 |

## Stress Test Results

Worst Scenario: **fees_2x** (score: 59.6868)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | 257.74 | 1.41 | 59.11 | 178.7228 |
| fees_2x | 160.65 | 1.29 | 65.46 | 59.6868 |
| latency_plus1 | 331.03 | 1.47 | 66.89 | 272.1350 |
| latency_plus2 | 317.89 | 1.56 | 44.47 | 269.3111 |
| latency_plus3 | 237.33 | 1.47 | 44.24 | 191.7443 |
| low_liquidity | 359.13 | 1.62 | 43.66 | 305.7425 |
| very_low_liquidity | 357.26 | 1.55 | 45.43 | 303.9747 |
| high_slippage | 322.57 | 1.51 | 54.94 | 264.5499 |
| extreme_slippage | 258.08 | 1.42 | 59.06 | 198.4711 |
| combined_adverse | 238.51 | 1.36 | 61.94 | 162.8330 |

## Stop-Ship Checks

- dataset_audit: PASS
- feature_parity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: PASS
- yaml_validates: PASS
- determinism: PASS
