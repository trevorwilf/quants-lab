# PMM Dynamic Optimization Report: nonkyc_BTC-USDT_5m_sweep_v1

Generated: 2026-03-07 06:35:04 UTC

## Dataset Summary

- **connector**: nonkyc
- **trading_pair**: BTC-USDT
- **interval**: 5m
- **n_candles**: 53417
- **dataset_hash**: 23cb6ae9ff646fb46eecc1eba7413a9c5e3ff9c0239d5024356c52a7ed8ebf63
- **n_trials_phase1**: 3000
- **n_candidates_stressed**: 50

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 2.8481202588236525 |
| buy_n_levels | 9 |
| buy_side_weight | 0.7587857104685791 |
| buy_spread_base | 4.142325340507382 |
| buy_spread_ratio | 2.990257185384812 |
| cooldown_time | 6561.804111898042 |
| executor_refresh_time | 12332.42127983572 |
| macd_fast | 12 |
| macd_signal | 15 |
| macd_slow | 30 |
| natr_length | 37 |
| sell_n_levels | 9 |
| sell_spread_base | 0.5233894472395599 |
| sell_spread_ratio | 1.2576726116213233 |
| stop_loss | 0.14132620285177439 |
| take_profit | 0.05856933421279177 |
| time_limit | 154204 |
| total_amount_quote | 675.3549669062712 |
| trailing_stop_activation | 0.014120747304836898 |
| trailing_stop_delta | 0.0033166118426189535 |

## Best Metrics

- **PnL %**: 165.0318
- **Net PnL (quote)**: 1114.5503
- **Sharpe Ratio**: 1.3575
- **Max Drawdown %**: 5.7015
- **Profit Factor**: 6.421856922641207
- **Trade Count**: 1053
- **Total Fees (quote)**: 80.1046
- **Maker Fees**: 26.2409
- **Taker Fees**: 53.8637
- **Fee Drag %**: 11.8611

## Objective Decomposition

- **Raw Score**: 161.4632
- **PnL Component**: 165.0318
- **Sharpe Component**: 0.6787
- **Drawdown Component**: -1.7105
- **Fee Drag Component**: -2.3722
- **Inventory Component**: -0.1580
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **-0.6588**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective |
|------|-------|--------|----------|--------|-----------|
| 0 | 0.03 | 2.20 | 0.09 | 24 | 0.5589 |
| 1 | 279.13 | 5.11 | 0.07 | 45 | 281.2999 |
| 2 | 0.02 | 0.31 | 0.43 | 59 | -0.0743 |
| 3 | 0.01 | 0.59 | 0.13 | 44 | 0.1015 |
| 4 | -0.19 | -3.99 | 0.32 | 63 | -1.4231 |
| 5 | 0.05 | 4.23 | 0.06 | 49 | 2.0702 |
| 6 | -0.16 | -7.72 | 0.21 | 43 | -1.4304 |
| 7 | 0.07 | 0.48 | 0.64 | 77 | -0.1146 |
| 8 | 0.14 | 2.65 | 0.30 | 72 | 1.2665 |
| 9 | -0.19 | -1.58 | 0.74 | 73 | -1.4637 |

## Stress Test Results

Worst Scenario: **fees_2x** (score: 146.1211)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | 159.11 | 1.34 | 7.51 | 153.7977 |
| fees_2x | 153.18 | 1.32 | 9.36 | 146.1211 |
| latency_plus1 | 167.18 | 1.36 | 5.17 | 163.8384 |
| latency_plus2 | 164.10 | 1.36 | 5.48 | 160.6878 |
| latency_plus3 | 166.04 | 1.36 | 5.53 | 162.5336 |
| low_liquidity | 165.02 | 1.36 | 5.70 | 161.4527 |
| very_low_liquidity | 166.40 | 1.36 | 5.21 | 163.0085 |
| high_slippage | 163.04 | 1.35 | 6.30 | 159.2854 |
| extreme_slippage | 159.05 | 1.34 | 7.51 | 154.9286 |
| combined_adverse | 159.43 | 1.34 | 7.50 | 154.2051 |

## Stop-Ship Checks

- dataset_audit: PASS
- feature_parity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: PASS
- yaml_validates: PASS
- determinism: PASS
