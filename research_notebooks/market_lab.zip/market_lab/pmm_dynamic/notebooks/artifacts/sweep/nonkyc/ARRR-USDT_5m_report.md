# PMM Dynamic Optimization Report: nonkyc_ARRR-USDT_5m_sweep_v1

Generated: 2026-03-19 05:31:52 UTC

## Dataset Summary

- **connector**: nonkyc
- **trading_pair**: ARRR-USDT
- **interval**: 5m
- **n_candles**: 55261
- **dataset_hash**: 1f357b9c9be6c3de6195bf883562e8b7d47c5fcf9d7d20e3a561b1ef170e514c
- **n_trials_phase1**: 12000
- **n_candidates_stressed**: 75
- **total_amount_quote_search_min**: 25.0
- **total_amount_quote_search_max**: 1000.0
- **total_amount_quote_ideal**: 26.746313186412195
- **search_controller_compat**: False

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 3.1656401649641053 |
| buy_n_levels | 6 |
| buy_side_weight | 0.49188574186065237 |
| buy_spread_base | 0.395386857475071 |
| buy_spread_ratio | 2.0339540633604845 |
| cooldown_time | 103 |
| executor_refresh_time | 411 |
| macd_fast | 26 |
| macd_signal | 20 |
| macd_slow | 42 |
| natr_length | 27 |
| sell_n_levels | 10 |
| sell_spread_base | 0.2542503463840599 |
| sell_spread_ratio | 1.3001638777844147 |
| stop_loss | 0.17765602335096445 |
| take_profit | 0.03831779047475349 |
| time_limit | 165245 |
| total_amount_quote | 26.746313186412195 |
| trailing_stop_activation | 0.03164633689760452 |
| trailing_stop_delta | 0.001535538856009545 |

## Best Metrics

- **PnL %**: 11899.2494
- **Net PnL (quote)**: 3182.6105
- **Sharpe Ratio**: 5.4372
- **Max Drawdown %**: 68.4863
- **Profit Factor**: 1.4743754865752219
- **Trade Count**: 27179
- **Total Fees (quote)**: 860.1968
- **Maker Fees**: 289.7686
- **Taker Fees**: 570.4283
- **Fee Drag %**: 3216.1324

## Objective Decomposition

- **Raw Score**: 11230.2466
- **PnL Component**: 11899.2494
- **Sharpe Component**: 2.5000
- **Drawdown Component**: -20.5459
- **Fee Drag Component**: -643.2265
- **Inventory Component**: -7.3250
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **830.2335**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective | Regime |
|------|-------|--------|----------|--------|-----------|--------|
| 0 | 2161.10 | 26.81 | 15.12 | 1510 | 2121.5087 | n/a |
| 1 | 1356.84 | 28.35 | 20.88 | 1228 | 1312.6734 | n/a |
| 2 | 959.08 | 21.18 | 12.81 | 1335 | 915.8585 | n/a |
| 3 | 1065.04 | 27.58 | 21.63 | 1137 | 1023.3055 | n/a |
| 4 | 752.57 | 33.30 | 6.62 | 1262 | 713.6926 | n/a |
| 5 | 2037.55 | 17.31 | 14.63 | 1425 | 1991.4305 | n/a |
| 6 | 947.08 | 19.73 | 30.26 | 1312 | 899.4150 | n/a |
| 7 | 907.86 | 29.04 | 18.98 | 1292 | 864.2123 | n/a |
| 8 | 729.24 | 30.53 | 7.10 | 1246 | 690.2928 | n/a |
| 9 | 872.54 | 22.46 | 5.27 | 1249 | 834.7492 | n/a |

## Stress Test Results

Worst Scenario: **latency_plus2** (score: -1000.0000)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | 11094.24 | 5.33 | 69.46 | 10119.0270 |
| fees_2x | 10306.37 | 5.19 | 70.37 | 9037.5665 |
| latency_plus1 | 8284.17 | 5.12 | 68.76 | 7801.1054 |
| latency_plus2 | 0.00 | 0.00 | 0.00 | -1000.0000 |
| latency_plus3 | 0.00 | 0.00 | 0.00 | -1000.0000 |
| low_liquidity | 10609.55 | 5.32 | 63.26 | 10007.3230 |
| very_low_liquidity | 9285.12 | 5.16 | 56.54 | 8770.7691 |
| high_slippage | 11588.48 | 5.40 | 68.96 | 10923.6805 |
| extreme_slippage | 11151.27 | 5.33 | 69.55 | 10491.9126 |
| combined_adverse | 6835.84 | 4.86 | 67.97 | 6196.9775 |
| spread_widen_10bps | 11805.72 | 5.40 | 69.10 | 11141.3475 |
| spread_widen_25bps | 11482.43 | 5.36 | 69.43 | 10823.4772 |
| thin_book | 5359.61 | 4.68 | 69.88 | 5035.5005 |
| very_thin_book | 2182.37 | 3.92 | 68.13 | 2037.4770 |
| entry_spread_stress | 11632.76 | 5.38 | 68.98 | 10969.7612 |
| combined_market_deterioration | 7215.44 | 4.90 | 70.29 | 6554.3009 |
| severe_adverse | 0.00 | 0.00 | 0.00 | -1000.0000 |

## Stop-Ship Checks

- dataset_audit: **FAIL**
- runtime_sanity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: **FAIL**
- yaml_validates: **FAIL**
- walkforward_robust: PASS
- walkforward_positive_majority: PASS
- holdout_passed: **FAIL**
- holdout_no_collapse: **FAIL**
- sensitivity_stable: **FAIL**
- recent_28d_passed: **FAIL**
- frozen_parity: **FAIL**
- top_k_clustered: **FAIL**

> **WARNING**: One or more stop-ship checks FAILED.
