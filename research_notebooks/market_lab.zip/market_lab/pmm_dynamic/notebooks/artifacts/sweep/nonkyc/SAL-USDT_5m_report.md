# PMM Dynamic Optimization Report: nonkyc_SAL-USDT_5m_sweep_v1

Generated: 2026-03-07 09:06:26 UTC

## Dataset Summary

- **connector**: nonkyc
- **trading_pair**: SAL-USDT
- **interval**: 5m
- **n_candles**: 53219
- **dataset_hash**: ecba94e85b2f3f443714c571ab2ddc03ad84c9e95f8a40452c298a4aff02ef60
- **n_trials_phase1**: 3000
- **n_candidates_stressed**: 50

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 3.8414114040421006 |
| buy_n_levels | 8 |
| buy_side_weight | 0.7650654008905677 |
| buy_spread_base | 0.2455781787834087 |
| buy_spread_ratio | 1.2812064775528758 |
| cooldown_time | 544.4684916109143 |
| executor_refresh_time | 1211.6079158569034 |
| macd_fast | 25 |
| macd_signal | 7 |
| macd_slow | 27 |
| natr_length | 36 |
| sell_n_levels | 3 |
| sell_spread_base | 3.138338242431442 |
| sell_spread_ratio | 1.389551237531549 |
| stop_loss | 0.2337258585442735 |
| take_profit | 0.0777444615843668 |
| time_limit | 97048 |
| total_amount_quote | 44.704554731535566 |
| trailing_stop_activation | 0.06249458239484349 |
| trailing_stop_delta | 0.002049630799475388 |

## Best Metrics

- **PnL %**: 8722.7241
- **Net PnL (quote)**: 3899.4550
- **Sharpe Ratio**: -0.2153
- **Max Drawdown %**: 207.1455
- **Profit Factor**: 1.8122700600994033
- **Trade Count**: 25774
- **Total Fees (quote)**: 524.7569
- **Maker Fees**: 172.0920
- **Taker Fees**: 352.6649
- **Fee Drag %**: 1173.8332

## Objective Decomposition

- **Raw Score**: 8334.4899
- **PnL Component**: 8722.7241
- **Sharpe Component**: -0.1076
- **Drawdown Component**: -62.1436
- **Fee Drag Component**: -234.7666
- **Inventory Component**: -82.7587
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **511.6177**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective |
|------|-------|--------|----------|--------|-----------|
| 0 | 1688.81 | -3.57 | 165.64 | 1781 | 1185.1816 |
| 1 | 1140.32 | 10.42 | 76.44 | 1764 | 1073.3185 |
| 2 | -148.65 | -4.70 | 296.96 | 1762 | -2380.4964 |
| 3 | 314.12 | 5.15 | 112.77 | 1754 | -55.6989 |
| 4 | 614.61 | 8.87 | 69.08 | 1792 | 527.9119 |
| 5 | 856.52 | 5.67 | 99.82 | 1763 | 752.8026 |
| 6 | 1196.94 | 6.42 | 156.90 | 1719 | 1050.3597 |
| 7 | 427.93 | 9.91 | 99.34 | 1793 | 303.2990 |
| 8 | 1247.37 | -3.32 | 298.75 | 1736 | 1067.6434 |
| 9 | 730.51 | 10.02 | 81.39 | 1847 | 643.0083 |

## Stress Test Results

Worst Scenario: **very_low_liquidity** (score: 3153.3952)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | 8135.81 | 0.05 | 225.59 | 7549.4497 |
| fees_2x | 7548.89 | -1.72 | 244.37 | 6849.1206 |
| latency_plus1 | 7573.14 | -1.07 | 200.53 | 7158.7729 |
| latency_plus2 | 6580.99 | 1.15 | 225.14 | 5982.3600 |
| latency_plus3 | 5412.91 | -0.20 | 220.92 | 5034.2239 |
| low_liquidity | 6138.31 | -0.53 | 145.26 | 5820.1543 |
| very_low_liquidity | 3392.53 | 1.98 | 181.50 | 3153.3952 |
| high_slippage | 8525.80 | 1.40 | 213.10 | 4912.1529 |
| extreme_slippage | 8131.94 | 0.52 | 225.09 | 7502.6285 |
| combined_adverse | 4675.93 | 0.60 | 177.12 | 4275.3681 |

## Stop-Ship Checks

- dataset_audit: PASS
- feature_parity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: PASS
- yaml_validates: PASS
- determinism: PASS
