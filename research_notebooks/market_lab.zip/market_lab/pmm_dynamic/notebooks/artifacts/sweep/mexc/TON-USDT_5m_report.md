# PMM Dynamic Optimization Report: mexc_TON-USDT_5m_sweep_v1

Generated: 2026-03-19 11:58:39 UTC

## Dataset Summary

- **connector**: mexc
- **trading_pair**: TON-USDT
- **interval**: 5m
- **n_candles**: 55234
- **dataset_hash**: 535ed685f8ba7c3c578f0c0188b22a5e9b0cce71069d987fcd333bb0f9990284
- **n_trials_phase1**: 12000
- **n_candidates_stressed**: 75
- **total_amount_quote_search_min**: 25.0
- **total_amount_quote_search_max**: 1000.0
- **total_amount_quote_ideal**: 237.24463831710025
- **search_controller_compat**: False

## Best Parameters

| Parameter | Value |
|-----------|-------|
| amount_skew | 2.665849236589518 |
| buy_n_levels | 8 |
| buy_side_weight | 0.40651041332115456 |
| buy_spread_base | 0.35689119000399055 |
| buy_spread_ratio | 1.255312987568511 |
| cooldown_time | 320 |
| executor_refresh_time | 1048 |
| macd_fast | 18 |
| macd_signal | 12 |
| macd_slow | 69 |
| natr_length | 11 |
| sell_n_levels | 8 |
| sell_spread_base | 0.21854480829075762 |
| sell_spread_ratio | 1.346865605771541 |
| stop_loss | 0.24320871699869342 |
| take_profit | 0.1264492885903694 |
| time_limit | 167207 |
| total_amount_quote | 237.24463831710025 |
| trailing_stop_activation | 0.0210126707028452 |
| trailing_stop_delta | 0.0014669952782254418 |

## Best Metrics

- **PnL %**: 1778.0589
- **Net PnL (quote)**: 4218.3494
- **Sharpe Ratio**: 3.3269
- **Max Drawdown %**: 48.8133
- **Profit Factor**: 1.7407326406475712
- **Trade Count**: 20696
- **Total Fees (quote)**: 309.3419
- **Maker Fees**: 156.3829
- **Taker Fees**: 152.9590
- **Fee Drag %**: 130.3894

## Objective Decomposition

- **Raw Score**: 1732.4587
- **PnL Component**: 1778.0589
- **Sharpe Component**: 1.6634
- **Drawdown Component**: -14.6440
- **Fee Drag Component**: -26.0779
- **Inventory Component**: -6.4126
- **Trade Count Penalty**: -0.0000
- **Rejected**: False

## Walk-Forward Results

Aggregate Score: **91.8123**

| Fold | PnL % | Sharpe | Max DD % | Trades | Objective | Regime |
|------|-------|--------|----------|--------|-----------|--------|
| 0 | 168.57 | 38.76 | 4.29 | 1309 | 162.9225 | n/a |
| 1 | 213.23 | 32.78 | 5.89 | 1434 | 206.5844 | n/a |
| 2 | 146.23 | 33.25 | 5.65 | 1223 | 140.2096 | n/a |
| 3 | 86.73 | 30.10 | 3.45 | 994 | 82.6001 | n/a |
| 4 | 73.03 | 26.94 | 2.63 | 977 | 69.5383 | n/a |
| 5 | 110.72 | 32.83 | 5.49 | 1198 | 105.6310 | n/a |
| 6 | 92.51 | 28.29 | 7.48 | 1047 | 86.4432 | n/a |
| 7 | 258.51 | 31.40 | 14.23 | 1270 | 250.3741 | n/a |
| 8 | 73.38 | 28.02 | 3.36 | 938 | 68.8652 | n/a |
| 9 | 118.93 | 30.93 | 4.58 | 1116 | 113.3293 | n/a |

## Stress Test Results

Worst Scenario: **severe_adverse** (score: 395.5172)

| Scenario | PnL % | Sharpe | Max DD % | Objective |
|----------|-------|--------|----------|-----------|
| fees_1.5x | 1717.43 | 3.30 | 64.09 | 1654.2758 |
| fees_2x | 1708.36 | 3.31 | 32.99 | 1641.5697 |
| latency_plus1 | 1559.09 | 3.23 | 61.20 | 1512.1383 |
| latency_plus2 | 1291.82 | 3.25 | 29.22 | 1257.9197 |
| latency_plus3 | 1051.70 | 2.91 | 40.30 | 1017.3340 |
| low_liquidity | 1771.51 | 3.32 | 58.02 | 1723.3633 |
| very_low_liquidity | 1765.08 | 3.32 | 48.20 | 1720.0861 |
| high_slippage | 1678.38 | 3.28 | 46.82 | 1633.5785 |
| extreme_slippage | 1541.00 | 3.18 | 61.96 | 1491.5491 |
| combined_adverse | 1477.22 | 3.20 | 34.74 | 1426.3241 |
| spread_widen_10bps | 1661.03 | 3.27 | 45.15 | 1616.6612 |
| spread_widen_25bps | 1575.04 | 3.25 | 24.83 | 1536.9760 |
| thin_book | 1102.46 | 2.97 | 75.58 | 1058.4364 |
| very_thin_book | 464.09 | 2.38 | 71.40 | 429.7514 |
| entry_spread_stress | 1638.81 | 3.25 | 49.13 | 1593.0349 |
| combined_market_deterioration | 1217.61 | 3.01 | 75.33 | 1159.9914 |
| severe_adverse | 440.07 | 2.29 | 71.98 | 395.5172 |

## Stop-Ship Checks

- dataset_audit: **FAIL**
- runtime_sanity: PASS
- objective_not_degenerate: PASS
- stress_not_collapsed: PASS
- yaml_validates: **FAIL**
- walkforward_robust: PASS
- walkforward_positive_majority: PASS
- holdout_passed: **FAIL**
- holdout_no_collapse: **FAIL**
- sensitivity_stable: **FAIL**
- recent_28d_passed: **FAIL**
- frozen_parity: **FAIL**
- top_k_clustered: **FAIL**

> **WARNING**: One or more stop-ship checks FAILED.
