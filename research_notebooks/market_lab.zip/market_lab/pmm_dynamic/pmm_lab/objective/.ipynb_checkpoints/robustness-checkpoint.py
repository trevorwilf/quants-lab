"""
Robust aggregation of scores across folds and stress scenarios.
"""

import numpy as np
from typing import List

from pmm_lab.objective.objective import REJECT_SCORE


def robust_aggregate(
    scores: List[float],
    lambda_mad: float = 0.5,
) -> float:
    """Compute a robust aggregate score.

    Formula: robust_score = median(scores) - lambda_mad * MAD(scores)

    Where MAD = median(|scores - median(scores)|)

    Parameters
    ----------
    scores : List[float]
        Objective scores from individual folds or scenarios.
    lambda_mad : float
        Penalty weight for variability. Default 0.5.

    Returns
    -------
    float
        Robust aggregate score.
        Returns REJECT_SCORE (-1000.0) if scores is empty or all REJECT_SCORE.
    """
    if not scores:
        return REJECT_SCORE

    arr = np.array(scores, dtype="float64")

    # Filter out REJECT_SCORE values
    valid = arr[arr != REJECT_SCORE]
    if len(valid) == 0:
        return REJECT_SCORE

    median_val = float(np.median(valid))
    mad = float(np.median(np.abs(valid - median_val)))

    return median_val - lambda_mad * mad
